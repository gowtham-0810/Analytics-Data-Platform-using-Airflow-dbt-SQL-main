{{
    config(
        materialized = 'table',
        unique_key = 'lga_code_2016',
        alias = 'census_g02'
    )
}}

with source as (
    select * from {{ref("b_census_g02")}}
)

select * from source